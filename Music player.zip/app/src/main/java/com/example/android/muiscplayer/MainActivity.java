package com.example.android.muiscplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    Button playbtn;
    Seekbar positionbar;
    Textview elapsedtimelabel;
    Textview remainingtimelabel;
    Mediaplayer mp;
    int Totaltime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playbtn=(Button)findViewById(R.id.play);
        elapsedtimelabel=(Textview)findViewById(R.id.elasedTimelabe);
        remainingtimelabel=(Textview)findViewById(R.id.remainingTimelabel);
        //mediaplayer
        mp=Mediaplayer.create(this,R.raw.music);
        mp.setlooping(true);
        mp.seekTo(0);
        mp.setVolume(0.5f,0.5f);
        Totaltime=mp.getDuration();
        //position bar
        positionbar=(Seekbar)findviewById(R.id.positionbar);
        positionbar.setMax(Totaltime);

        //volume

        volumebar=(SeekBar)findViewById(R.id.volumebar);
        volumebar.setOnSeekBarChangeListener(){

            @Override
                    public void onProgressChanged(Seekbar seekbar,int i,boolean b) {

                if(b){
                    mp.seekTo(i);
                    positionBar.setProgress(i);
                }


            }

            @Override
                    public void onStartTrackingTouch(Seekbar seekbar) {


            }

            @Override
                    public void onStopTrackingTouch(SeekBar seekBar){




        }






    }

    //thread update(position bar and timelabel)

        new Thread(new Runnable())
        {
            @Override
             public void run(){

                while(mp!=null) {
                    try {

                        message msg=new Message();
                        msg.what=mp.getCurrentPosition();
                        handler.sendmessage(msg);
                        Thread.sleep(1000);


                    } catch(InterruptedException e) {

                    }


                }
            }
        }.start()
    }
     private Handler handle=new Handler() {

        @Override
         public void handleMessage(Message msg) {
            int currentposition=msg.what;
            positionbar.setProgress(currentPosition);
            String elapsedTime=createTimeLabel(currentPosition);
            elapsedtimelabel.setText(elapsedTime);


            String remainingTime=createTimeLabe(totalTime-currentposition);
            remainingtimelabel.setText(remainingTime);

        }


     };

    public String createTimeLabel(int view) {


        String timelabel="";
        int min=time/100;
        int sec=time/1000%60;


        timeLabel=min+"";
        if(sec<=10) timeLabel+="0";
        timeLabel+=sec;

        return timeLabel;
    }








    public void playbtnclick(View v) {

        if(!mp.isPlaying())
            //stopping
            mp.start();

    }
    else {

        //playing

        mp.pause()
    }

}
